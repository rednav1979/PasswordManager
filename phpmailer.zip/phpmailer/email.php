<?php
 require 'PHPMailerAutoload.php';
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'mail.grupounita.com.br';
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Username = 'suporte@grupounita.com.br';
    $mail->Password = '?rB1*r)o6*aX';
    $mail->Port = 587;
    $mail->setFrom('vanderlei.clemente@grupounita.com.br', 'Contato');
    $mail->addAddress('vanderlei.clemente@grupounita.com.br');
    //$mail->SMTPDebug = 3;
    //$mail->Debugoutput = 'html';
    //$mail->setLanguage('pt');
    $mail->isHTML(true);
   $mail->Subject = "TESTE DE ASSUNTO";
   $mail->Body    = "CORPO DO EMAIL1";
   $mail->AltBody = "CORPO DO EMAIL2";
;

   if(!$mail->send()) {
       echo 'N�o foi poss�vel enviar a mensagem.<br>';
       echo 'Erro: ' . $mail->ErrorInfo;
   } else {
    echo "Seu email foi enviado com sucesso!"; 
   }

?>